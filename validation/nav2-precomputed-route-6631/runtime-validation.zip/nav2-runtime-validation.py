"""Real Nav2 processes with a minimal unicycle base simulator, without hardware."""
import csv
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import time

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from action_msgs.msg import GoalStatus
from geometry_msgs.msg import TransformStamped, TwistStamped
from lifecycle_msgs.srv import ChangeState, GetState
from lifecycle_msgs.msg import Transition
from nav_msgs.msg import Odometry
from nav2_msgs.action import TrackPrecomputedRoute, FollowPath, ComputeRoute
from nav2_msgs.srv import SetRouteGraph
from std_srvs.srv import Trigger
from tf2_ros import TransformBroadcaster, StaticTransformBroadcaster

ROOT=Path('/work/nav2-runtime')
ROOT.mkdir(exist_ok=True)
points={1:(0.0,0.0),2:(3.0,0.0),3:(3.0,3.0)}
features=[{'type':'Feature','properties':{'id':i,'frame':'map'},'geometry':{'type':'Point','coordinates':list(p)}} for i,p in points.items()]
for edge,start,end in [(10,1,2),(20,2,3)]:
    features.append({'type':'Feature','properties':{'id':edge,'startid':start,'endid':end},'geometry':{'type':'LineString','coordinates':[points[start],points[end]]}})
(ROOT/'graph.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features}))

class BaseSimulator(Node):
    def __init__(self):
        super().__init__('precomputed_runtime_validation')
        self.x=self.y=self.yaw=self.v=self.w=0.0
        self.last=time.monotonic()
        self.last_command=self.last
        self.phase='startup'
        self.commands=0
        self.feedback=[]
        self.samples=[]
        self.tf=TransformBroadcaster(self)
        self.static_tf=StaticTransformBroadcaster(self)
        transform=TransformStamped()
        transform.header.frame_id='map'
        transform.child_frame_id='odom'
        transform.transform.rotation.w=1.0
        transform.header.stamp=self.get_clock().now().to_msg()
        self.static_tf.sendTransform(transform)
        self.pub=self.create_publisher(Odometry,'odom',10)
        self.sub=self.create_subscription(TwistStamped,'cmd_vel',self.command,10)
        self.timer=self.create_timer(0.02,self.step)
        self.track=ActionClient(self,TrackPrecomputedRoute,'track_precomputed_route')
        self.follow=ActionClient(self,FollowPath,'follow_path')
        self.compute=ActionClient(self,ComputeRoute,'compute_route')

    def command(self,msg):
        self.v=msg.twist.linear.x
        self.w=msg.twist.angular.z
        assert math.isfinite(self.v) and math.isfinite(self.w)
        self.last_command=time.monotonic()
        self.commands+=1

    def step(self):
        now=time.monotonic()
        dt=min(now-self.last,0.1)
        self.last=now
        if now-self.last_command>0.5:
            self.v=self.w=0.0
        self.x+=self.v*math.cos(self.yaw)*dt
        self.y+=self.v*math.sin(self.yaw)*dt
        self.yaw+=self.w*dt
        stamp=self.get_clock().now().to_msg()
        transform=TransformStamped()
        transform.header.frame_id='odom'
        transform.child_frame_id='base_link'
        transform.header.stamp=stamp
        transform.transform.translation.x=self.x
        transform.transform.translation.y=self.y
        transform.transform.rotation.z=math.sin(self.yaw/2)
        transform.transform.rotation.w=math.cos(self.yaw/2)
        self.tf.sendTransform(transform)
        odom=Odometry()
        odom.header.frame_id='odom'
        odom.child_frame_id='base_link'
        odom.header.stamp=stamp
        odom.pose.pose.position.x=self.x
        odom.pose.pose.position.y=self.y
        odom.pose.pose.orientation=transform.transform.rotation
        odom.twist.twist.linear.x=self.v
        odom.twist.twist.angular.z=self.w
        self.pub.publish(odom)
        self.samples.append([now,self.phase,self.x,self.y,self.yaw,self.v,self.w])

    def spin(self,seconds):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            rclpy.spin_once(self,timeout_sec=0.02)

    def wait(self,future,timeout=10):
        until=time.monotonic()+timeout
        while not future.done() and time.monotonic()<until:
            rclpy.spin_once(self,timeout_sec=0.02)
        assert future.done(),f'Future timed out during {self.phase}'
        return future.result()

    def service(self,service_type,name,request):
        client=self.create_client(service_type,name)
        assert client.wait_for_service(timeout_sec=10),name
        response=self.wait(client.call_async(request))
        self.destroy_client(client)
        return response

    def lifecycle(self,name,transition):
        request=ChangeState.Request()
        request.transition.id=transition
        assert self.service(ChangeState,name+'/change_state',request).success,(name,transition)

    def reset(self,phase):
        self.phase=phase
        self.x=self.y=self.yaw=self.v=self.w=0.0
        self.feedback=[]
        self.spin(0.4)

    def send_track(self,id,edges=(10,20)):
        goal=TrackPrecomputedRoute.Goal()
        goal.route_id=id
        goal.start_node_id=1
        goal.edge_ids=list(edges)
        handle=self.wait(self.track.send_goal_async(goal,feedback_callback=lambda msg:self.feedback.append(msg.feedback)))
        assert handle.accepted
        until=time.monotonic()+5
        while not any(f.route_id==id for f in self.feedback) and time.monotonic()<until:
            rclpy.spin_once(self,timeout_sec=0.02)
        assert any(f.route_id==id for f in self.feedback)
        return handle

    def send_follow(self,id):
        path=next(f.path for f in self.feedback if f.route_id==id)
        goal=FollowPath.Goal()
        goal.path=path
        goal.controller_id='FollowPath'
        goal.goal_checker_id='goal_checker'
        goal.progress_checker_id='progress_checker'
        goal.path_handler_id='PathHandler'
        handle=self.wait(self.follow.send_goal_async(goal))
        assert handle.accepted
        return handle

def run():
    rclpy.init()
    node=BaseSimulator()
    processes=[]
    logs=[]
    result={'platform':subprocess.check_output(['uname','-a'],text=True).strip(),'ros_distro':os.environ['ROS_DISTRO'],'domain':os.environ['ROS_DOMAIN_ID'],'simulation':'kinematic base only; real route_server, controller_server, RPP and ROS middleware','scenarios':[]}
    try:
        for package,executable in [('nav2_route','route_server'),('nav2_controller','controller_server')]:
            log=(ROOT/(executable+'.log')).open('w')
            logs.append(log)
            executable_path=Path('/work/nav2-development/install')/package/'lib'/package/executable
            processes.append(subprocess.Popen([str(executable_path),'--ros-args','--params-file',str(ROOT/'params.yaml')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True))
        node.spin(1)
        for name in ['route_server','controller_server']:
            node.lifecycle(name,Transition.TRANSITION_CONFIGURE)
            node.lifecycle(name,Transition.TRANSITION_ACTIVATE)
        assert node.track.wait_for_server(timeout_sec=5)
        assert node.follow.wait_for_server(timeout_sec=5)
        print('REAL_NODES_ACTIVE',flush=True)

        node.reset('complete_L_route')
        tracked=node.send_track('runtime-complete')
        followed=node.send_follow('runtime-complete')
        tracking=node.wait(tracked.get_result_async(),timeout=45)
        following=node.wait(followed.get_result_async(),timeout=10)
        assert tracking.status==GoalStatus.STATUS_SUCCEEDED and tracking.result.error_code==0
        assert following.status==GoalStatus.STATUS_SUCCEEDED and following.result.error_code==0
        error=math.hypot(node.x-3,node.y-3)
        assert error<0.15,error
        ids=[f.current_edge_id for f in node.feedback]
        assert 10 in ids and 20 in ids,ids
        assert node.commands>20
        result['scenarios'].append({'name':'L-shaped exact route with real RPP controller','passed':True,'final_xy':[node.x,node.y],'goal_error_m':error,'cmd_vel_messages':node.commands,'edge_feedback':ids})
        print('COMPLETE_ROUTE_PASS',error,flush=True)

        node.reset('cancel')
        tracked=node.send_track('runtime-cancel')
        followed=node.send_follow('runtime-cancel')
        node.spin(1.5)
        request=SetRouteGraph.Request()
        request.graph_filepath=str(ROOT/'graph.geojson')
        assert not node.service(SetRouteGraph,'route_server/set_route_graph',request).success
        assert node.wait(tracked.cancel_goal_async()).goals_canceling
        assert node.wait(followed.cancel_goal_async()).goals_canceling
        assert node.wait(tracked.get_result_async()).status==GoalStatus.STATUS_CANCELED
        assert node.wait(followed.get_result_async()).status==GoalStatus.STATUS_CANCELED
        node.spin(0.2)
        stopped=(node.x,node.y)
        node.spin(0.6)
        drift=math.hypot(node.x-stopped[0],node.y-stopped[1])
        assert drift<0.01 and abs(node.v)<1e-3,drift
        assert node.service(SetRouteGraph,'route_server/set_route_graph',request).success
        result['scenarios'].append({'name':'cancel both actions; stop commands; graph lease released','passed':True,'post_cancel_drift_m':drift})
        print('CANCEL_AND_GRAPH_PASS',flush=True)

        node.reset('preempt')
        original=node.send_track('runtime-old')
        replacement=node.send_track('runtime-new',(10,))
        prior=node.wait(original.get_result_async())
        assert prior.status==GoalStatus.STATUS_ABORTED and prior.result.route_id=='runtime-old'
        followed=node.send_follow('runtime-new')
        tracking=node.wait(replacement.get_result_async(),timeout=20)
        following=node.wait(followed.get_result_async(),timeout=10)
        assert tracking.status==following.status==GoalStatus.STATUS_SUCCEEDED
        assert tracking.result.route_id=='runtime-new'
        assert math.hypot(node.x-3,node.y)<0.15
        result['scenarios'].append({'name':'preempt old route and drive replacement using real controller','passed':True,'old_result_id':prior.result.route_id,'new_result_id':tracking.result.route_id,'final_xy':[node.x,node.y]})
        print('PREEMPT_PASS',flush=True)

        node.reset('external_reroute')
        tracked=node.send_track('runtime-blocked')
        followed=node.send_follow('runtime-blocked')
        node.spin(1)
        assert node.service(Trigger,'route_server/ReroutingService/reroute',Trigger.Request()).success
        aborted=node.wait(tracked.get_result_async())
        assert aborted.status==GoalStatus.STATUS_ABORTED
        assert aborted.result.error_code==TrackPrecomputedRoute.Result.REROUTE_REQUIRED
        assert aborted.result.route_id=='runtime-blocked'
        assert node.wait(followed.cancel_goal_async()).goals_canceling
        assert node.wait(followed.get_result_async()).status==GoalStatus.STATUS_CANCELED
        result['scenarios'].append({'name':'operation requests external replanning; controller canceled by client','passed':True,'error_code':aborted.result.error_code,'route_id':aborted.result.route_id})
        print('REROUTE_PASS',flush=True)

        node.phase='lifecycle'
        for name in ['controller_server','route_server']:
            node.lifecycle(name,Transition.TRANSITION_DEACTIVATE)
            node.lifecycle(name,Transition.TRANSITION_CLEANUP)
            node.lifecycle(name,Transition.TRANSITION_CONFIGURE)
            node.lifecycle(name,Transition.TRANSITION_ACTIVATE)
        for name in ['controller_server','route_server']:
            state=node.service(GetState,name+'/get_state',GetState.Request())
            assert state.current_state.label=='active'
        result['scenarios'].append({'name':'deactivate, cleanup, reconfigure and reactivate both real servers','passed':True})
        result['passed']=True
        print('ALL_RUNTIME_SCENARIOS_PASS',flush=True)
    except Exception as exc:
        result['passed']=False
        result['error']=repr(exc)
        raise
    finally:
        (ROOT/'results.json').write_text(json.dumps(result,indent=2))
        with (ROOT/'trajectory.csv').open('w',newline='') as stream:
            writer=csv.writer(stream)
            writer.writerow(['time','phase','x','y','yaw','linear_velocity','angular_velocity'])
            writer.writerows(node.samples)
        for process in processes:
            if process.poll() is None:
                os.killpg(process.pid,signal.SIGINT)
        for process in processes:
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGTERM)
                process.wait(timeout=5)
        for log in logs:
            log.close()
        node.destroy_node()
        rclpy.shutdown()

if __name__=='__main__':
    run()
